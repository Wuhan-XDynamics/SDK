#pragma once

void RP_GetRGBMappingPt(vector<Point>& TrayHole, vector<Point>& TrayHoleMap, LEN_IMAP* pstInterpMap, int width, int height);

bool RP_CalcOutRgb2CaliCoorMap(COOR_MAP* pstCoorMap, int iWidth, int iHeight);

void GLB_GetCoordinateMapInROI(int iXMapUnitLen, int iYMapUnitLen,
    int iXMapTimes, int iYMapTimes, int* piXMapLUT, int* piYMapLUT,
    RECT16S rsThisROIRect, int* piRoiXMapLUT, int* piRoiYMapLUT,
    int* piRoiXMapUnitLen, int* piRoiYMapUnitLen,
    int* piRoiXMapTimes, int* piRoiYMapTimes);

bool RP_RgbLEN_CreateUndistortMap(RP_RGB_LENS* pstRgbLens, int iWidth, int iHeight, COOR_MAP* pstCoorMap, LEN_IMAP* pstInterpMap);

void RP_RgbLEN_Undistort(unsigned char* pucImage, LEN_IMAP* pstInterpMap, int width, int height);


