#include <iostream>
#include <fstream>
#include <sstream>
#include <signal.h>

#ifdef _WIN32
#include <Windows.h>
#elif __linux__
#include <unistd.h>
#include <sys/time.h>
#endif
#include "xdyn_streamer.h"
#include "xdyn_define.h"
#include "xdyn_utils.h"
#include "depth2PC.h"

#include <ros/ros.h>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/PointCloud.h>
#include <sensor_msgs/point_cloud_conversion.h>
#include <pcl_ros/point_cloud.h>
#include <cv_bridge/cv_bridge.h>

#define FW_MAJOR_VERSION 	1
#define FW_MINOR_VERSION 	0
#define FW_REVISION_VERSION 7
ros::Publisher publisher_pc2;
//ros::Publisher publisher_confidence;
ros::Publisher publisher_gray;

using namespace XD;

bool doExit = false;
struct UserHandler
{
    XDYN_Streamer *stream;
    void *user;
    PCConver pcConver;
    PCPoint_t *pcAttr;
    uint32_t imgSize;
	uint32_t imgWidth;
	uint32_t imgHeight;
	pcl::PointCloud<pcl::PointXYZ> cloud;
    uint32_t other;
};

static void SaveImageData_depth(void *data, uint32_t size, int max = 10)
{

    static int cnt = 0;
    static std::ofstream ofstrm;

    if(cnt >= max) return;

    if(!ofstrm.is_open()){
        ofstrm.open("depth.dat", std::ios::binary | std::ios::out);
    }

    ofstrm << std::string((char *)data, size);

    cnt ++;
    if(cnt == max){
        ofstrm.close();
    }
}

static void SaveImageData_gray(void *data, uint32_t size, int max = 10)
{

    static int cnt = 0;
    static std::ofstream ofstrm;

    if(cnt >= max) return;

    if(!ofstrm.is_open()){
        ofstrm.open("gray.dat", std::ios::binary | std::ios::out);
    }

    ofstrm << std::string((char *)data, size);

    cnt ++;
    if(cnt == max){
        ofstrm.close();
    }
}

static void SaveImageData_amp(void *data, uint32_t size, int max = 10)
{

    static int cnt = 0;
    static std::ofstream ofstrm;

    if(cnt >= max) return;

    if(!ofstrm.is_open()){
        ofstrm.open("amp.dat", std::ios::binary | std::ios::out);
    }

    ofstrm << std::string((char *)data, size);

    cnt ++;
    if(cnt == max){
        ofstrm.close();
    }
}

static void SaveImageData_pointcloud(void *data, uint32_t size, int max = 10)
{

    static int cnt = 0;
    static std::ofstream ofstrm;

    if(cnt >= max) return;

    if(!ofstrm.is_open()){
        ofstrm.open("point_cloud.dat", std::ios::binary | std::ios::out);
    }

    ofstrm << std::string((char *)data, size);

    cnt ++;
    if(cnt == max){
        ofstrm.close();
    }
}

static void SavePointCloud_ply(void *data, uint32_t size)
{
    static int num = 0;
    bool isLimitConfidence = true;
    float validConfidenceMin = 0.8f;
    std::ofstream plyFile(std::string("pt_") + std::to_string(num) + std::string(".ply"), std::ios::out);
    if(!plyFile.is_open()){
        std::cout << "open failed, return" << std::endl;
        return ;
    }

    num ++;

    float *pTmp = nullptr;
    int len = size / sizeof(float);
    int eleCnt = 0;

    pTmp = (float *)data;
    for(int i  = 0; i < len; i += 4, pTmp += 4){
        if(isLimitConfidence && pTmp[3] < validConfidenceMin)
            continue;
        eleCnt ++;
    }

    // add ply header info
    plyFile << "ply\n";
    plyFile << "format ascii 1.0\n";
    plyFile << "element vertex " << std::to_string(eleCnt) << "\n";
    plyFile << "property float x\n";
    plyFile << "property float y\n";
    plyFile << "property float z\n";
    plyFile << "end_header\n";

    pTmp = (float *)data;
    for(int i = 0 ; i < len; i += 4, pTmp += 4){
        std::string outStr = "";
        if(isLimitConfidence && pTmp[3] < validConfidenceMin){
			outStr += std::to_string(0);
        	outStr += " ";
        	outStr += std::to_string(0);
        	outStr += " ";
        	outStr += std::to_string(0);
        	outStr += "\n";
		}else{
	        outStr += std::to_string(pTmp[0]);
	        outStr += " ";
	        outStr += std::to_string(pTmp[1]);
	        outStr += " ";
	        outStr += std::to_string(pTmp[2]);
	        outStr += "\n";
		}
		
        plyFile << outStr;
    }

    plyFile.close();
}

void EventCB(void *handle, int event, void *data)
{
    UserHandler *user = (UserHandler *)handle;
}

void StreamCB(void *handle, MemSinkCfg *cfg, XdynFrame_t *data)
{

    UserHandler *user = (UserHandler *)handle;

    // wo can do some user handler
    // warnning : 这个回调函数内部不适合做耗时很大的操作，请注意

    printf("get stream data: ");
    for(int i = 0; i < MEM_AGENT_SINK_MAX; i ++){
        printf("[%d:%d] ", i, cfg->isUsed[i]);
    }
    printf("\n");

	if(cfg->isUsed[MEM_AGENT_SINK_DEPTH] && data[MEM_AGENT_SINK_DEPTH].addr && 
		cfg->isUsed[MEM_AGENT_SINK_CONFID] && data[MEM_AGENT_SINK_CONFID].addr){

		//SaveImageData_depth(data[MEM_AGENT_SINK_DEPTH].addr, data[MEM_AGENT_SINK_DEPTH].size, 10);
        if(data[MEM_AGENT_SINK_DEPTH].ex){
            XdynDepthFrameInfo_t *depthInfo = (XdynDepthFrameInfo_t *)data[MEM_AGENT_SINK_DEPTH].ex;
            if(!user->pcConver.IsInit()){
				MemSinkInfo info;
                user->stream->GetResolution(info);
                user->pcConver.Init(info, depthInfo->fUnitOfDepth, depthInfo->fLensParas);
                user->imgSize = info.width * info.height;
                user->pcAttr  = (PCPoint_t *)calloc(1, info.width * info.height * sizeof(PCPoint_t));
				user->cloud.width  = user->imgWidth;
			    user->cloud.height = user->imgHeight;
			    user->cloud.points.resize(user->cloud.width * user->cloud.height);
    		}

	       // 将深度转化为点云
			user->pcConver.Depth2PC((uint16_t *)data[MEM_AGENT_SINK_DEPTH].addr, user->pcAttr);

			// 保存点云
			// SaveImageData_pointcloud(user->pcAttr, user->imgSize * sizeof(PCPoint_t));
			printf("get depth size [%d], fUnitOfDepth = %f, hz[%f, %f]\n", 
					data[MEM_AGENT_SINK_DEPTH].size, depthInfo->fUnitOfDepth, depthInfo->fModFreqMHZ[0], depthInfo->fModFreqMHZ[1]);
			
			sensor_msgs::PointCloud2 output;	    
			
			float *pTmp = (float *)user->pcAttr;
			unsigned char *pConf = (unsigned char*)data[MEM_AGENT_SINK_CONFID].addr;
			unsigned int i, j;
			for(i= 0, j=0; i < user->imgWidth * user->imgHeight; i++, j+=3){
				if(pConf[i] > 100){
					user->cloud.points[i].x = pTmp[j];
					user->cloud.points[i].y = pTmp[j+1];
					user->cloud.points[i].z = pTmp[j+2];
				}
				else{
					user->cloud.points[i].x = 0;
					user->cloud.points[i].y = 0;
					user->cloud.points[i].z = 0;
				}
			}					
		 
		    //Convert the cloud to ROS message
		    pcl::toROSMsg(user->cloud, output);

			output.header.frame_id = "xd500";
			output.header.stamp = ros::Time::now();
			
			publisher_pc2.publish(output);
        }
	}

	if(cfg->isUsed[MEM_AGENT_SINK_GRAY] && data[MEM_AGENT_SINK_GRAY].addr)
	{
		printf("get gray size [%d]\n", data[MEM_AGENT_SINK_GRAY].size);

		std_msgs::Header header;
		header.frame_id = "xd500";
		header.stamp = ros::Time::now();
		cv::Mat confidence_img = cv::Mat(cv::Size(user->imgWidth, user->imgHeight), CV_16U, data[MEM_AGENT_SINK_GRAY].addr);
		publisher_gray.publish(*cv_bridge::CvImage(header, sensor_msgs::image_encodings::TYPE_16UC1, confidence_img).toImageMsg());
    }
}

void SignalFunc(int signNo)
{    
    doExit = true;
    ros::shutdown();
}

int main(int argc, char *argv[])
{
    int res = XD_SUCCESS;

    ros::init(argc, argv, "xd500_publisher");
    ros::NodeHandle nh;
    publisher_pc2 = nh.advertise<sensor_msgs::PointCloud2>("/xd500/pointCloud2", 1);
	//publisher_confidence = nh.advertise<sensor_msgs::Image>("/xd500/confidence_image", 1);
	publisher_gray = nh.advertise<sensor_msgs::Image>("/xd500/gray_image", 1);
	
    signal(SIGINT, SignalFunc); // ctrl + c
#ifdef _WIN32
    signal(SIGBREAK, SignalFunc);
#endif
    	
    UserHandler userHdl;

    MemSinkCfg memCfg;
    XdynCamInfo_t camInfo;
    unsigned int phaseInt[4] = {2500000, 2500000, 0, 0};
    unsigned int specialInt[4] = {2500000, 2500000, 0, 0};

    // init context
    XdynContextInit();

    std::vector<XdynProductDesc_t> prtList;
    ScanProductFromNet(prtList, "192.168.31.3");
    if(prtList.empty()){
        printf("not found product connect, return\n");
        return -1;
    }

    printf("scan product list :\n");
    for(auto i = 0; i < prtList.size(); i ++){
        printf("    type = %d, werlfID = 0x%08x, inter1 = %d, inter2 = %d\n",
                   prtList[i].type, prtList[i].warelfID, prtList[i].inter1, prtList[i].inter2);
    }

     //XDYN_Streamer *stream = CreateStreamerNet(XDYN_PRODUCT_TYPE_XD_500, EventCB, &userHdl, "192.168.31.253");
    XDYN_Streamer *stream = CreateStreamer((XDYN_PRODUCT_TYPE_e)prtList[0].type, prtList[0].inter1, 
                            EventCB, &userHdl, prtList[0].prtIP);
    if(stream == nullptr){
        printf("get streamer failed, return\n");
        return -1;
    }
    
    XdynVersion_t version;
    stream->GetVersion(1, version);
    printf("SDK version %d.%d.%d.%d\n", version.major, version.minor, version.revision,version.temp);
	printf("FW version %d.%d.%d\n", FW_MAJOR_VERSION, FW_MINOR_VERSION, FW_REVISION_VERSION);

    userHdl.stream = stream;

    res = stream->OpenCamera(XDYN_DEV_TYPE_TOF);
    if(res != XD_SUCCESS){
        printf("open camera failed, exitm [%d]\n", res);
        goto END;
    }

    memCfg.isUsed[MEM_AGENT_SINK_DEPTH] = true;
    //memCfg.isUsed[MEM_AGENT_SINK_GRAY] = true;
    memCfg.isUsed[MEM_AGENT_SINK_CONFID] = true;
    res = stream->ConfigSinkType(XDYN_SINK_TYPE_CB, memCfg, StreamCB, &userHdl);
    if(res != XD_SUCCESS){
        printf("config sink type failed, return [%d]\n", res);
        goto END;
    }

    res = stream->ConfigAlgMode(XDYN_ALG_MODE_EMB_ALG_IPC_PASS);
    if(res != XD_SUCCESS){
        printf("config alg failed, return [%d]\n", res);
        goto END;
    }

    stream->SetFps(5);
    stream->SetCamFreq(124, 23);
    stream->SetCamInt(phaseInt, specialInt);
    stream->SetCamBinning(XDYN_BINNING_MODE_2x2); // 使用binning 2x2的方法，分辨率为320 * 240
    stream->SetPhaseMode(XDYN_PHASE_MODE_16);
    userHdl.imgWidth = 320;
	userHdl.imgHeight = 240;
    res = stream->ConfigCamParams();
    if(res != XD_SUCCESS){
        printf("conifg cam params failed, [%d]\n", res);
        goto END;
    }

    res = stream->StartStreaming();
    if(res != XD_SUCCESS){
        printf("strart streaming failed, [%d]\n", res);
        goto END;
    }
    
    while (!doExit){
        #ifdef _WIN32
        Sleep(1000);
        #elif __linux__
        usleep(1000000);
        #endif
        // stream->GetCamInfo(&camInfo);
        // printf("chipID = %08x, UID[0] = %08x, UID[1] = %08x, tSensor = %d\n", 
        //         camInfo.tofChipID, camInfo.tofUID[0], camInfo.tofUID[1], camInfo.tSensor);
    }

END:
    stream->StopStreaming();
    stream->CloseCamera();
    DestroyStreamer(stream);

    XdynContextUninit();
    return 0;
}




